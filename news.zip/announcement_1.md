---
layout: post
date: 2024-09-26 15:59:00-0400
inline: true
related_posts: false
---

Our paper 'Why the Metric Backbone Preserves Community Structure' has been accepted at NeurIPS! See you in Vancouver.
